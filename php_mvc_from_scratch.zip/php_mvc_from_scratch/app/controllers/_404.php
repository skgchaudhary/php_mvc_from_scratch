<?php
    class _404 extends Controller {
        public function index() {
            echo "This page does not exists.";
        }
    }