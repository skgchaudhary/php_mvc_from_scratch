<?php
    define("ROOT", "");
    define("DBHOST", "sql212.hstn.me");
    define("DBNAME", "mseet_38391577_db");
    define("DBUSER", "mseet_38391577");
    define("DBPASS", "cpzgsU8TCexO");